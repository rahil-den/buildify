# Buildify — the idea machine

Three pages, each with its own slot machine and its own build-ready pick of the day:

| Page | File | Data | Machine reels | Daily section |
|---|---|---|---|---|
| Home: startup ideas | `index.html` | `data/ideas.json` | Business · Audience · Twist | Idea of the day |
| CLI projects | `cli.html` | `data/cli.json` | Tool · Users · Twist | Project of the day |
| Web & mobile apps | `apps.html` | `data/apps.json` | App · Users · Twist | App of the day |

Every daily pick comes with the problem, who pays, pricing, an MVP checklist, how to get the first ten users and (for CLI and apps) a suggested tech stack. Any machine result also has a **See the build brief** button.

Nothing is hardcoded in the pages. All ideas live in the three data files, which grow three ways:

1. **You edit them** (add ideas, reel pieces, anything).
2. **Daily picks from Claude** (optional): a GitHub Action writes the next day's pick for every page each morning and adds one new reel piece per page.
3. **Suggestions from visitors**: they fill in a GitHub form, you add the `approved` label, and it's scheduled on the right page automatically.

With none of the optional parts turned on, every page still changes daily by rotating through its hand-picked backlog (24 startup ideas, 12 CLI projects, 12 apps).

## What's in here

```
index.html, cli.html, apps.html   the three pages
assets/site.css, assets/app.js    shared look and machine code
data/*.json                       every idea, reel piece and build brief
scripts/validate.mjs              checks the data files before each deploy
scripts/embed-data.mjs            bakes the latest data into each page at deploy time
scripts/daily-ideas.mjs           writes the daily picks with Claude (runs in GitHub Actions)
scripts/add-submission.mjs        turns an approved suggestion into an entry
.github/workflows/                deploy, daily picks, approved suggestions
.github/ISSUE_TEMPLATE/           the two "suggest" forms visitors fill in
```

## Preview it on your computer

Double-click any of the HTML files; each page carries a built-in copy of its data. To preview exactly like the live site, run this in the folder and open http://localhost:8000:

```
python3 -m http.server
```

After editing a data file, run `node scripts/embed-data.mjs` if you want double-clicked pages to show your edits too. The live site does this automatically on every deploy.

## Publish on GitHub Pages (free)

1. Create a new **public** repository on GitHub, for example `buildify`.
2. Upload everything in this folder, keeping the folders (`assets`, `data`, `scripts`, `.github`). The branch must be called `main`.
   The `.github` folder is hidden on Mac and Linux and easy to miss when dragging files into the browser, so pushing with git is safer:
   ```
   git init && git add . && git commit -m "Buildify" && git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/buildify.git
   git push -u origin main
   ```
3. In the repo, go to **Settings → Pages** and set **Source** to **GitHub Actions**.
4. Go to the **Actions** tab, open **Deploy site**, and click **Run workflow**. It also runs on every push to `main`.
5. After a minute the site is live at `https://YOUR-USERNAME.github.io/buildify/`, with the other pages at `.../cli.html` and `.../apps.html`.

Want it at `YOUR-USERNAME.github.io` with nothing after it? Name the repository `YOUR-USERNAME.github.io` instead.

## Turn on daily picks from Claude (optional)

1. Get an API key at https://console.anthropic.com. This is separate from a Claude.ai subscription and is billed per use; a few short requests a day cost very little.
2. In the repo: **Settings → Secrets and variables → Actions → New repository secret**. Name it `ANTHROPIC_API_KEY` and paste the key.
3. That's it. Every day at 06:17 UTC the **Daily ideas** workflow writes today's and tomorrow's picks for all three pages, checks them, commits the data files and redeploys. Run it by hand from the Actions tab to try it right away.

Every entry is checked before it's saved: required fields, sensible lengths, and not too similar to an existing one. If Claude's answer fails three times, nothing is saved and that page uses its backlog for the day. Each page has its own brief for Claude (for example, CLI picks must be publishable terminal tools with a realistic open-source money model), which you can edit at the top of `scripts/daily-ideas.mjs`.

To use a different model, add a repository **variable** (not a secret) named `IDEA_MODEL` with a model name from https://docs.claude.com/en/docs/about-claude/models/overview. The default is `claude-sonnet-5`.

Prefer to review AI picks before they go live? Change `daily-ideas.yml` to open a pull request instead of pushing (for example with the `peter-evans/create-pull-request` action).

## Let visitors suggest ideas

Each page's **Suggest an idea** button and **Add a reel piece** link open a GitHub issue form in your repo, with that page already chosen. Visitors need a free GitHub account.

1. Create a label named exactly `approved`: **Issues → Labels → New label**.
2. When a good suggestion comes in, add the `approved` label. The **Add approved idea** workflow adds it to the right data file, schedules it on the next free day, comments the date on the issue, closes it and redeploys.
3. If something is missing, too similar to an existing entry, or uses a type from a different page, the bot comments with what to fix instead.

Only people with write access can add labels, so nothing goes live without you.

On `github.io` the site works out your repo automatically. On a custom domain, set it in each data file:

```json
"config": { "repo": "YOUR-USERNAME/buildify" }
```

## Editing by hand

Open a data file on GitHub and click the pencil icon.

- **`page`** sets the reel labels and icons (`briefcase`, `people`, `sparkle`, `terminal`, `devices`), the daily section's name, the example idea, and a default `stack` used in machine build briefs.
- **Reel pieces.** `reels.business` (the first reel) items start with "a" or "an" and use a `tag` that exists in `money.byTag` and `build.byTag`. `reels.audience` items start with "for". `reels.twist` items start with a lowercase word so they read mid-sentence ("where…", "that…", "with…"). Audience and twist items carry their own `money: { "t": "title", "n": "note" }`. `w` (−2 to 1) nudges the verdict: the three weights add up to Genius, Good, Mid, Bad or Cursed. Add `"added": "2026-09-24"` and the piece shows a NEW tag for a week.
- **Daily picks.** `title`, `pitch`, `problem`, `whoPays`, `pricing`, `stack` (optional), `mvp` (3–6 steps), `firstUsers`, `difficulty` (1–3), `tags`. Give one a `"date": "2026-10-02"` to pin it to that day; entries without a date rotate on the other days.

Every deploy runs `node scripts/validate.mjs` first, so a typo stops the deploy instead of breaking the site. The failed run in the Actions tab says exactly which entry is wrong.

## Adding a fourth page later

Copy `cli.html` to a new file, change its `data-track`, `data-src`, title and hero text, and create the matching data file. Then add the page to `TRACKS` in `scripts/lib.mjs`, to `CONFIG` in `scripts/daily-ideas.mjs`, to the nav in each page, and to the "Which page is it for?" options in the two issue forms.

## Good to know

- GitHub pauses scheduled workflows in repositories with no activity for 60 days. The daily commits keep it active; without an API key the schedule has nothing to do anyway.
- GitHub Pages caches files for up to ten minutes, so an update can take a moment to show up.
